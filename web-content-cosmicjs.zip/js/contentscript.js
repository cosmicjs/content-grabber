//this script  created by "Fady Ayoob " email => fadyAyoobDev@gmail.com


AddLoader();
HideLoader();
AddSaveButton();
HideButton();
GetSelectedText();
LoadButtonPosition();

setInterval(function () {load(); }, 500);

